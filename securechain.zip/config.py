import pyodbc

def get_connection():
    """Retourne une connexion à SQL Server"""
    try:
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=DESKTOP-7A08N1S\\SQLEXPRESS;'  # À MODIFIER
            'DATABASE=SecureChain;'
            'Trusted_Connection=yes;'
            'Timeout=5;'
        )
        return conn
    except Exception as e:
        print(f"Erreur connexion DB: {e}")
        raise