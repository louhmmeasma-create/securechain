import hashlib

def calculate_hash(index, filename, file_hash, previous_hash):
    """Calcule le hash d'un bloc"""
    value = f"{index}{filename}{file_hash}{previous_hash}"
    return hashlib.sha256(value.encode()).hexdigest()

def verify_chain(blocks):
    """Vérifie l'intégrité de toute la chaîne"""
    for i in range(1, len(blocks)):
        if blocks[i]['previous_hash'] != blocks[i-1]['file_hash']:
            return False, i
    return True, -1