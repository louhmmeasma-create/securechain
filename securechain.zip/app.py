from flask import Flask, render_template, request, redirect, url_for, flash, session, send_file
from config import get_connection
from crypto import generate_keys, hash_data, sign_data, verify_signature, encrypt_file, decrypt_file
from blockchain import calculate_hash
import os
import pickle
from functools import wraps
from datetime import datetime, timedelta
import io
import re

app = Flask(__name__)
app.secret_key = 'votre_cle_secrete_tres_longue_et_aleatoire_123456789'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024

# Sécuriser les sessions
app.config.update(
    SESSION_COOKIE_SECURE=False,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Lax',
    PERMANENT_SESSION_LIFETIME=timedelta(hours=1)
)

# Créer les dossiers nécessaires
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs('keys', exist_ok=True)

# ============================================
# FONCTIONS UTILITAIRES
# ============================================

def validate_username(username):
    return re.match("^[a-zA-Z0-9_]{3,20}$", username) is not None

def sanitize_filename(filename):
    filename = re.sub(r'[^a-zA-Z0-9._-]', '', filename)
    return filename

# ============================================
# DÉCORATEUR LOGIN REQUIRED
# ============================================
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('❌ Vous devez être connecté pour accéder à cette page', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# ============================================
# ROUTES PRINCIPALES
# ============================================

@app.route('/')
def index():
    if 'lang' not in session:
        session['lang'] = 'fr'
    
    conn = None
    cursor = None
    blocks = []
    
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT TOP 5 b.id, b.filename, b.user_id, b.timestamp, u.username 
            FROM Blocks b
            LEFT JOIN Users u ON b.user_id = u.id
            ORDER BY b.id DESC
        """)
        
        for row in cursor.fetchall():
            blocks.append({
                'id': row[0],
                'filename': row[1],
                'user_id': row[2],
                'username': row[4] or f'User #{row[2]}',
                'timestamp': row[3].strftime('%d/%m/%Y %H:%M') if row[3] else 'N/A'
            })
            
    except Exception as e:
        flash(f'Erreur: {str(e)}', 'error')
    finally:
        if cursor: cursor.close()
        if conn: conn.close()
    
    return render_template('index.html', blocks=blocks)

@app.route('/upload-page')
def upload_page():
    return render_template('upload.html')

@app.route('/verify-page')
def verify_page():
    return render_template('verify.html')

@app.route('/set-language/<lang>')
def set_language(lang):
    if lang in ['fr', 'en']:
        session['lang'] = lang
    return redirect(request.referrer or url_for('index'))

# ============================================
# AUTHENTIFICATION
# ============================================

@app.route('/register', methods=['GET', 'POST'])
def register_page():
    if 'lang' not in session:
        session['lang'] = 'fr'
    
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        if not validate_username(username):
            flash('❌ Nom d\'utilisateur invalide (3-20 caractères, lettres, chiffres, _)', 'error')
            return redirect(url_for('register_page'))
        
        if len(password) < 6:
            flash('❌ Mot de passe trop court (minimum 6 caractères)', 'error')
            return redirect(url_for('register_page'))
        
        private_key, public_key = generate_keys()
        
        conn = None
        cursor = None
        
        try:
            conn = get_connection()
            cursor = conn.cursor()
            
            cursor.execute("SELECT id FROM Users WHERE username = ?", (username,))
            if cursor.fetchone():
                flash('❌ Ce nom d\'utilisateur existe déjà', 'error')
                return redirect(url_for('register_page'))
            
            cursor.execute(
                "INSERT INTO Users (username, password, public_key) VALUES (?, ?, ?)",
                (username, password, public_key.decode())
            )
            conn.commit()
            
            cursor.execute("SELECT @@IDENTITY")
            user_id = cursor.fetchone()[0]
            
            with open(f'keys/user_{user_id}_private.pem', 'wb') as f:
                f.write(private_key)
            
            flash('✅ Inscription réussie ! Connectez-vous.', 'success')
            return redirect(url_for('login'))
            
        except Exception as e:
            flash(f'❌ Erreur: {str(e)}', 'error')
        finally:
            if cursor: cursor.close()
            if conn: conn.close()
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'lang' not in session:
        session['lang'] = 'fr'
    
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = None
        cursor = None
        
        try:
            conn = get_connection()
            cursor = conn.cursor()
            
            cursor.execute(
                "SELECT id, username FROM Users WHERE username = ? AND password = ?",
                (username, password)
            )
            user = cursor.fetchone()
            
            if user:
                session['user_id'] = user[0]
                session['username'] = user[1]
                flash(f'✅ Bienvenue {username} !', 'success')
                return redirect(url_for('dashboard'))
            else:
                flash('❌ Nom d\'utilisateur ou mot de passe incorrect', 'error')
                
        except Exception as e:
            flash(f'❌ Erreur: {str(e)}', 'error')
        finally:
            if cursor: cursor.close()
            if conn: conn.close()
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('✅ Déconnexion réussie', 'success')
    return redirect(url_for('index'))

# ============================================
# DASHBOARD
# ============================================

@app.route('/dashboard')
@login_required
def dashboard():
    user_id = session['user_id']
    conn = None
    cursor = None
    
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT id, username FROM Users WHERE id = ?", (user_id,))
        user = cursor.fetchone()
        
        cursor.execute("SELECT COUNT(*) FROM Blocks WHERE user_id = ?", (user_id,))
        files_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM Blocks")
        total_blocks = cursor.fetchone()[0]
        
        cursor.execute("SELECT TOP 1 filename, timestamp FROM Blocks WHERE user_id = ? ORDER BY timestamp DESC", (user_id,))
        last = cursor.fetchone()
        
        stats = {
            'files_count': files_count,
            'total_blocks': total_blocks,
            'last_file': last[0] if last else 'Aucun',
            'last_date': last[1].strftime('%d/%m/%Y') if last else 'N/A'
        }
        
        return render_template('dashboard.html', 
                             user={'id': user[0], 'username': user[1]},
                             stats=stats)
        
    except Exception as e:
        flash(f'❌ Erreur: {str(e)}', 'error')
        return redirect(url_for('index'))
    finally:
        if cursor: cursor.close()
        if conn: conn.close()

# ============================================
# MES FICHIERS
# ============================================

@app.route('/my-files')
@login_required
def my_files():
    user_id = session['user_id']
    conn = None
    cursor = None
    files = []
    
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, filename, file_hash, timestamp 
            FROM Blocks 
            WHERE user_id = ? 
            ORDER BY timestamp DESC
        """, (user_id,))
        
        for row in cursor.fetchall():
            files.append({
                'id': row[0],
                'filename': row[1],
                'file_hash': row[2][:20] + '...',
                'timestamp': row[3].strftime('%d/%m/%Y %H:%M') if row[3] else 'N/A'
            })
            
    except Exception as e:
        flash(f'Erreur: {str(e)}', 'error')
    finally:
        if cursor: cursor.close()
        if conn: conn.close()
    
    return render_template('my_files.html', files=files)

# ============================================
# BLOCKCHAIN
# ============================================

@app.route('/blocks')
def blocks():
    conn = None
    cursor = None
    blocks_list = []
    
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT b.id, b.filename, b.user_id, b.timestamp, u.username 
            FROM Blocks b
            LEFT JOIN Users u ON b.user_id = u.id
            ORDER BY b.id DESC
        """)
        
        for row in cursor.fetchall():
            blocks_list.append({
                'id': row[0],
                'filename': row[1],
                'user_id': row[2],
                'username': row[4] or f'User #{row[2]}',
                'timestamp': row[3].strftime('%d/%m/%Y %H:%M') if row[3] else 'N/A'
            })
            
    except Exception as e:
        flash(f'Erreur: {str(e)}', 'error')
    finally:
        if cursor: cursor.close()
        if conn: conn.close()
    
    return render_template('blocks.html', blocks=blocks_list)

# ============================================
# UPLOAD
# ============================================

@app.route('/upload', methods=['POST'])
def upload():
    if 'file' not in request.files:
        flash('❌ Aucun fichier sélectionné', 'error')
        return redirect(url_for('upload_page'))
    
    file = request.files['file']
    if file.filename == '':
        flash('❌ Nom de fichier vide', 'error')
        return redirect(url_for('upload_page'))
    
    try:
        user_id = int(request.form['user_id'])
    except:
        flash('❌ ID utilisateur invalide', 'error')
        return redirect(url_for('upload_page'))
    
    file_data = file.read()
    filename = sanitize_filename(file.filename)
    
    file_hash = hash_data(file_data)
    
    encrypted_data, key, nonce, tag = encrypt_file(file_data)
    
    with open(os.path.join(app.config['UPLOAD_FOLDER'], f"{file_hash}.enc"), 'wb') as f:
        f.write(encrypted_data)
    
    with open(os.path.join(app.config['UPLOAD_FOLDER'], f"{file_hash}.meta"), 'wb') as f:
        pickle.dump({'key': key, 'nonce': nonce, 'tag': tag}, f)
    
    conn = None
    cursor = None
    
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        try:
            with open(f'keys/user_{user_id}_private.pem', 'rb') as f:
                private_key = f.read()
        except:
            from crypto import generate_keys
            private_key, _ = generate_keys()
            flash('⚠️ Clé temporaire utilisée', 'warning')
        
        signature = sign_data(file_hash.encode(), private_key)
        
        cursor.execute("SELECT TOP 1 file_hash FROM Blocks ORDER BY id DESC")
        last = cursor.fetchone()
        previous_hash = last[0] if last else "0"
        
        cursor.execute("SELECT COUNT(*) FROM Blocks")
        block_index = cursor.fetchone()[0] + 1
        block_hash = calculate_hash(block_index, filename, file_hash, previous_hash)
        
        cursor.execute(
            "INSERT INTO Blocks (filename, file_hash, previous_hash, signature, user_id) VALUES (?, ?, ?, ?, ?)",
            (filename, file_hash, previous_hash, signature, user_id)
        )
        conn.commit()
        
        flash('✅ Fichier ajouté à la blockchain avec succès !', 'success')
        
    except Exception as e:
        flash(f'❌ Erreur upload: {str(e)}', 'error')
    finally:
        if cursor: cursor.close()
        if conn: conn.close()
    
    return redirect(url_for('upload_page'))

# ============================================
# VÉRIFICATION
# ============================================

@app.route('/verify/<int:block_id>')
def verify(block_id):
    conn = None
    cursor = None
    
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM Blocks WHERE id = ?", (block_id,))
        block = cursor.fetchone()
        
        if not block:
            flash(f'❌ Bloc #{block_id} non trouvé', 'error')
            return redirect(url_for('verify_page'))
        
        filename = block[1]
        stored_hash = block[2]
        signature = block[4]
        user_id = block[5]
        
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], f"{stored_hash}.enc")
        meta_path = os.path.join(app.config['UPLOAD_FOLDER'], f"{stored_hash}.meta")
        
        if not os.path.exists(file_path) or not os.path.exists(meta_path):
            flash(f'❌ Fichier non trouvé', 'error')
            return redirect(url_for('verify_page'))
        
        with open(file_path, 'rb') as f:
            encrypted_data = f.read()
        
        with open(meta_path, 'rb') as f:
            meta = pickle.load(f)
        
        original_data = decrypt_file(encrypted_data, meta['key'], meta['nonce'], meta['tag'])
        new_hash = hash_data(original_data)
        
        cursor.execute("SELECT public_key, username FROM Users WHERE id = ?", (user_id,))
        user = cursor.fetchone()
        
        if not user:
            flash('❌ Utilisateur non trouvé', 'error')
            return redirect(url_for('verify_page'))
        
        public_key = user[0].encode()
        username = user[1]
        
        hash_valid = (new_hash == stored_hash)
        signature_valid = verify_signature(stored_hash.encode(), signature, public_key)
        
        cursor.execute("SELECT file_hash FROM Blocks WHERE id = ?", (block_id-1,))
        prev = cursor.fetchone()
        prev_valid = (prev and prev[0] == block[3]) or (block_id == 1 and block[3] == "0")
        
        if hash_valid and signature_valid and prev_valid:
            flash(f'✅ Bloc #{block_id} : Fichier authentique et intact !', 'success')
        else:
            errors = []
            if not hash_valid:
                errors.append("Hash modifié")
            if not signature_valid:
                errors.append("Signature invalide")
            if not prev_valid:
                errors.append("Chaîne rompue")
            flash(f'❌ Bloc #{block_id} : {", ".join(errors)}', 'error')
        
    except Exception as e:
        flash(f'❌ Erreur vérification: {str(e)}', 'error')
    finally:
        if cursor: cursor.close()
        if conn: conn.close()
    
    return redirect(url_for('verify_page'))

@app.route('/verify-block', methods=['POST'])
def verify_block():
    block_id = request.form['block_id']
    return redirect(url_for('verify', block_id=block_id))

# ============================================
# STATISTIQUES
# ============================================

@app.route('/stats')
def stats():
    conn = None
    cursor = None
    
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM Users")
        total_users = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM Blocks")
        total_blocks = cursor.fetchone()[0]
        
        cursor.execute("""
            SELECT TOP 1 u.username, COUNT(*) as files 
            FROM Users u 
            JOIN Blocks b ON u.id = b.user_id 
            GROUP BY u.username 
            ORDER BY files DESC
        """)
        top = cursor.fetchone()
        
        cursor.execute("SELECT COUNT(DISTINCT user_id) FROM Blocks")
        active_users = cursor.fetchone()[0]
        
        cursor.execute("SELECT MIN(timestamp), MAX(timestamp) FROM Blocks")
        dates = cursor.fetchone()
        
        stats_data = {
            'total_users': total_users,
            'total_blocks': total_blocks,
            'active_users': active_users,
            'top_user': top[0] if top else 'N/A',
            'top_files': top[1] if top else 0,
            'first_block': dates[0].strftime('%d/%m/%Y') if dates[0] else 'N/A',
            'last_block': dates[1].strftime('%d/%m/%Y') if dates[1] else 'N/A'
        }
        
        return render_template('stats.html', stats=stats_data)
        
    except Exception as e:
        flash(f'Erreur: {str(e)}', 'error')
        return redirect(url_for('index'))
    finally:
        if cursor: cursor.close()
        if conn: conn.close()

# ============================================
# TÉLÉCHARGEMENT
# ============================================

@app.route('/download/<int:block_id>')
@login_required
def download_file(block_id):
    conn = None
    cursor = None
    
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT filename, file_hash, user_id FROM Blocks WHERE id = ?", (block_id,))
        block = cursor.fetchone()
        
        if not block:
            flash('❌ Bloc non trouvé', 'error')
            return redirect(url_for('my_files'))
        
        filename, file_hash, owner_id = block
        
        if owner_id != session.get('user_id'):
            flash('❌ Vous n\'êtes pas propriétaire de ce fichier', 'error')
            return redirect(url_for('my_files'))
        
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], f"{file_hash}.enc")
        meta_path = os.path.join(app.config['UPLOAD_FOLDER'], f"{file_hash}.meta")
        
        with open(file_path, 'rb') as f:
            encrypted = f.read()
        
        with open(meta_path, 'rb') as f:
            meta = pickle.load(f)
        
        data = decrypt_file(encrypted, meta['key'], meta['nonce'], meta['tag'])
        
        return send_file(
            io.BytesIO(data),
            as_attachment=True,
            download_name=filename,
            mimetype='application/octet-stream'
        )
        
    except Exception as e:
        flash(f'❌ Erreur téléchargement: {str(e)}', 'error')
        return redirect(url_for('my_files'))
    finally:
        if cursor: cursor.close()
        if conn: conn.close()

# ============================================
# LANCEMENT
# ============================================

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000) 